HTML5 Image Preview
=================

This little script will allow user to see uplaoded image before they actually submit it.

Script does not require any third party library (jQuery, Mootools etc.). Full functionality
has been tested on PC, Android and iOS. 

Supported Image formats:

- JPG
- JPEG
- PNG
- GIF
- SVG
- WEBP (only chrome)

Find Example and Documentation at http://tomasdostal.com/projects/html5ImagePreview

Enjoy!
